Bonjour M.

j'ai eu quelque soucis car j'ai n'ai pas pu lancer npm install

j'ai perdu du temps pour pas grand chose mais j'ai fait le max sans pourvoir lancer l'application
je n'ai jamais lancer de serveur angular donc je ne pouver pas savoir 
j'ai met le rapport d'erreur dans le fichier 
c'est ma dernière chance de passer votre examin
donc je vous souhaite conne courage et continuation